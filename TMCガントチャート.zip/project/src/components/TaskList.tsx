import React from 'react';
import { Task } from '../types';
import { format } from 'date-fns';
import { TrashIcon } from '@heroicons/react/24/outline';

interface TaskListProps {
  tasks: Task[];
  onDeleteTask: (taskId: string) => void;
}

export const TaskList: React.FC<TaskListProps> = ({ tasks, onDeleteTask }) => {
  return (
    <div className="space-y-4">
      {tasks.map((task) => (
        <div key={task.id} className="bg-white p-4 rounded-lg shadow group">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-semibold text-lg">{task.name}</h3>
              <div className="text-sm text-gray-600 mt-1">
                <span>{format(new Date(task.startDate), 'yyyy/MM/dd')}</span>
                <span className="mx-2">→</span>
                <span>{format(new Date(task.endDate), 'yyyy/MM/dd')}</span>
              </div>
            </div>
            <button
              onClick={() => onDeleteTask(task.id)}
              className="text-gray-400 hover:text-red-500 transition-colors p-1 rounded-full hover:bg-red-50"
              title="タスクを削除"
            >
              <TrashIcon className="h-5 w-5" />
            </button>
          </div>
        </div>
      ))}
      {tasks.length === 0 && (
        <div className="text-center text-gray-500 py-4">
          タスクがありません。「＋ タスクを追加」ボタンからタスクを追加してください。
        </div>
      )}
    </div>
  );
};