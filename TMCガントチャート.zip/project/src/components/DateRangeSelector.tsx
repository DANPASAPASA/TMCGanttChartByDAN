import React from 'react';
import { format } from 'date-fns';

interface DateRangeSelectorProps {
  startDate: string;
  endDate: string;
  onStartDateChange: (date: string) => void;
  onEndDateChange: (date: string) => void;
}

export const DateRangeSelector: React.FC<DateRangeSelectorProps> = ({
  startDate,
  endDate,
  onStartDateChange,
  onEndDateChange,
}) => {
  return (
    <div className="flex items-center space-x-4">
      <div className="relative">
        <label htmlFor="viewStartDate" className="block text-sm font-medium text-gray-700 mb-1">
          開始日
        </label>
        <input
          type="date"
          id="viewStartDate"
          value={startDate}
          onChange={(e) => onStartDateChange(e.target.value)}
          className="block w-full rounded-full px-4 py-2 border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition-colors"
        />
      </div>
      <div className="relative">
        <label htmlFor="viewEndDate" className="block text-sm font-medium text-gray-700 mb-1">
          終了日
        </label>
        <input
          type="date"
          id="viewEndDate"
          value={endDate}
          onChange={(e) => onEndDateChange(e.target.value)}
          className="block w-full rounded-full px-4 py-2 border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition-colors"
        />
      </div>
    </div>
  );
};