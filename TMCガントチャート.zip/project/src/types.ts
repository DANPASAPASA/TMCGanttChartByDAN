export interface Task {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
}

export interface AddTaskFormData {
  name: string;
  startDate: string;
  endDate: string;
}