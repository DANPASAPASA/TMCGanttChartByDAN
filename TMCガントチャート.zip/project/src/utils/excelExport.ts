import * as XLSX from 'xlsx';
import { Task } from '../types';
import { format, eachDayOfInterval, isWithinInterval } from 'date-fns';

export const exportToExcel = (tasks: Task[]) => {
  // Calculate date range
  const allDates = tasks.flatMap(task => [new Date(task.startDate), new Date(task.endDate)]);
  const startDate = new Date(Math.min(...allDates.map(d => d.getTime())));
  const endDate = new Date(Math.max(...allDates.map(d => d.getTime())));
  const dateRange = eachDayOfInterval({ start: startDate, end: endDate });

  // Create headers
  const headers = ['タスク名', '開始日', '終了日', ...dateRange.map(date => format(date, 'MM/dd'))];

  // Create data rows
  const rows = tasks.map(task => {
    const baseRow = [
      task.name,
      format(new Date(task.startDate), 'yyyy/MM/dd'),
      format(new Date(task.endDate), 'yyyy/MM/dd'),
    ];

    // Add Gantt chart cells
    const ganttCells = dateRange.map(date =>
      isWithinInterval(date, {
        start: new Date(task.startDate),
        end: new Date(task.endDate),
      })
        ? '■'
        : ''
    );

    return [...baseRow, ...ganttCells];
  });

  // Create worksheet
  const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);

  // Create workbook
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'ガントチャート');

  // Generate Excel file
  XLSX.writeFile(wb, 'gantt-chart.xlsx');
};