import html2canvas from 'html2canvas';

export const exportToImage = async (elementId: string) => {
  const element = document.getElementById(elementId);
  if (!element) return;

  try {
    const canvas = await html2canvas(element, {
      backgroundColor: '#ffffff',
      scale: 2, // より高品質な画像のために2倍のスケールで描画
      useCORS: true,
      logging: false,
    });

    // canvasをPNG画像に変換
    const image = canvas.toDataURL('image/png');
    
    // ダウンロードリンクを作成
    const link = document.createElement('a');
    link.download = 'gantt-chart.png';
    link.href = image;
    
    // クリックイベントをトリガーしてダウンロードを開始
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } catch (error) {
    console.error('画像のエクスポートに失敗しました:', error);
  }
};