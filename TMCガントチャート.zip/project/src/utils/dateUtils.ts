import { addMonths, startOfMonth, endOfMonth, format } from 'date-fns';

export const getInitialDateRange = () => {
  const today = new Date();
  const startDate = startOfMonth(today);
  const endDate = endOfMonth(addMonths(today, 2)); // 3ヶ月分表示

  return {
    startDate: format(startDate, 'yyyy-MM-dd'),
    endDate: format(endDate, 'yyyy-MM-dd'),
  };
};